from django.contrib import admin

# Register your models here.
from .models import pizza
admin.site.register(pizza)