from django.shortcuts import render

# Create your views here.
from django.shortcuts import render,redirect,HttpResponse
from .models import pizza
# Create your views here.
def home(request):
    if request.method == 'POST':
        name = request.POST.get('pizza')
        return redirect('Topping',name)
    else:
        return render(request,'index.html')
def topping(request,hello):
    if request.method == "POST":
        tp1 = request.POST.getlist('topping')
        tp1.insert(0,hello)
        pizza = ' '
        for x in tp1:
            pizza = pizza + " " + x
        return redirect('Size',pizza)
    else:
        return render(request,'topping.html',{'hello':hello})
def size(request,final):
    if request.method == "POST":
        value = request.POST.get('size')
        if value == 'Small':
            size = 7
        else:
            if value == 'Medium':
                size = 9
            else:
                size = 12
        
        final = final + ' ' + value
        user = pizza(name=final,size=size)
        user.save()
        return redirect('done',final)
    else:
        return render(request,'size.html',{'final':final})
def done(request,final):
    return render(request,'final.html',{"final":final})
def show(request):
    pizza1 = pizza.objects.all()
    return render(request,'all.html',{'pizza1':pizza1})
def delete(request,id):
    pizza1 = pizza.objects.get(id=id)
    pizza1.delete()
    return redirect('show')
