from django.db import models

# Create your models here.
class pizza(models.Model):
    name = models.CharField(max_length=50, blank=True)
    size = models.IntegerField(blank=True)
    def __str__(self):
        return self.name